package com.infy.model;



public class ServiceReport {
	
}
