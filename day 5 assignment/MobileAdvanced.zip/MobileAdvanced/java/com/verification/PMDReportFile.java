package com.verification;

import java.util.List;

public class PMDReportFile
{
    public String filename;
    public List<PMDReportViolation> violations;
}