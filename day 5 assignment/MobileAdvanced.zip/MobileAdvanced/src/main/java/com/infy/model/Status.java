package com.infy.model;

public enum Status {
	ACCEPTED,REJECTED,COMPLETED,IN_PROGRESS 
}
