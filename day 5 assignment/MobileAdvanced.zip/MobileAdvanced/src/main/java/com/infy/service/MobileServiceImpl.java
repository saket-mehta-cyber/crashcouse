package com.infy.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.LogFactory;


import com.infy.dao.MobileServiceDAO;
import com.infy.dao.MobileServiceDAOImpl;
import com.infy.exception.MobileServiceException;
import com.infy.model.ServiceReport;
import com.infy.model.ServiceRequest;
import com.infy.model.Status;

import com.infy.validator.Validator;


import org.apache.commons.logging.Log;


public class MobileServiceImpl implements MobileService{
	private static final Log LOGGER = LogFactory.getLog(MobileServiceImpl.class);

	
	private MobileServiceDAO dao =  new MobileServiceDAOImpl();

	@Override
	public ServiceRequest registerRequest(ServiceRequest service) throws MobileServiceException {
		Validator validator = new Validator();
		validator.validate(service);
		try {
		float val = calculateEstimateCost(service.getIssues());
		
		if(val<=0) {
			throw new MobileServiceException("Service.INVALID_ISSUES");
		}
		else {
			service.setServiceFee(val);
			service.setStatus(Status.ACCEPTED);
			service.setTimeOfRequest(LocalDateTime.now());
			service= dao.registerRequest(service);
		}}catch(MobileServiceException e) {
			LOGGER.debug(e.getMessage(),e);
			throw  e;
			
		}
		 return service;
	}

	@Override
	public Float calculateEstimateCost(List<String> issues) throws MobileServiceException {
		float serviceFee=0;
		for(String a: issues) {
			if(a.equalsIgnoreCase("BATTERY")) {
				serviceFee=serviceFee+10;
			}
			if(a.equalsIgnoreCase("CAMERA")) {
				serviceFee=serviceFee+5;
			}
			if(a.equalsIgnoreCase("SCREEN")) {
				serviceFee=serviceFee+15;
			}
		}
		return serviceFee==0 ? 0 : serviceFee;
	}

	@Override
	public List<ServiceReport> getServices(Status status) throws MobileServiceException {
		try {
		List<ServiceReport> sr = new ArrayList<ServiceReport>();
		List<ServiceRequest> sr1 = dao.getServices();
		for(ServiceRequest i: sr1) {
			if(i.getStatus()==status) {
				ServiceReport srr = new ServiceReport(i.getServiceId(), i.getBrand(), i.getIssues(), i.getServiceFee());
				sr.add(srr);
			}
		}
		if(sr.isEmpty() || sr==null) {
			
			throw new MobileServiceException("Service.NO_RECORDS_FOUND");
		}
		else{
			return sr;
		}
		}catch(MobileServiceException e) {
			
			LOGGER.debug(e.getMessage(),e);
			throw  e;
			
		}
	}

}
