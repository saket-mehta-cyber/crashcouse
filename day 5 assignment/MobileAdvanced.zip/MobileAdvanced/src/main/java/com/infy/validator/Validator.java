package com.infy.validator;

import java.util.List;

import com.infy.exception.MobileServiceException;
import com.infy.model.ServiceRequest;

public class Validator {

	public void validate(ServiceRequest service) throws MobileServiceException {	
		if(!isValidBrand(service.getBrand())) {
			throw new MobileServiceException("Validator.INVALID_BRAND");
		}
		else if(!isValidIssues(service.getIssues())){
			throw new MobileServiceException("Validator.INVALID_NO_OF_ISSUES");	
		}
		else if(!isValidIMEINumber(service.getiMEINumber())){
			throw new MobileServiceException("Validator.INVALID_IMEI_NUMBER");	
		}
		else if(!isValidContactNumber(service.getContactNumber())){
			throw new MobileServiceException("Validator.INVALID_CONTACT_NUMBER");	
		}
		else if(!isValidCustomerName(service.getCustomerName())){
			throw new MobileServiceException("Validator.INVALID_CUSTOMER_NAME");	
		}
	}	

	
	// validates the brand
	// brand should always start with a upper case alphabet 
	// and can be followed by one or more alphabets (lower case or upper case) 
	public Boolean isValidBrand(String brand){
		String regex = "[A-Z][A-Za-z]+";   
		if(brand.matches(regex)) {
			return true;
		}
		return false;
	}
	
	
	// validates the list of issues
	// checks if the list is null or empty
	public Boolean isValidIssues(List<String> issues) {
		if(issues==null || issues.isEmpty()) {
			return false;
		}
		return true;
	}

	// validates the IMEINumber
	// it should be a 16 digit number 
	public Boolean isValidIMEINumber(Long iMEINumber) {
		String imei = String.valueOf(iMEINumber);
		if(imei.matches("[0-9]{16,16}")) {
			return true;
		}
		return false;
	}
	
	// validates the contact number
	// should contain 10 numeric characters and should not contain 10 repetitive characters
	public Boolean isValidContactNumber(Long contactNumber) {
		String contact = String.valueOf(contactNumber);
		String regex = contact.substring(0, 1)+"{10}";
		if(contact.length()==10 && !contact.matches(regex)) {
			return true;
		}
		return false;
	}
	
	
	// validates the customer name
	// should contain at least one word and each word separated by a single space should contain at least one letter.
	// the first letter of every word should be an upper case character 
	public Boolean isValidCustomerName(String customerName) {
		String regex = "([A-Z][a-z]+\\s?)+";    //John Abram L
		if(customerName.matches(regex)) {
			return true;
		}
		return false;
	}
}
