package com.infy.test;

import java.util.ArrayList;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


import com.infy.exception.MobileServiceException;

import com.infy.model.ServiceRequest;
import com.infy.service.MobileService;
import com.infy.service.MobileServiceImpl;
import com.infy.validator.Validator;


public class MobileServiceTest {

    private MobileService mobileService= new MobileServiceImpl();
    Validator validator=new Validator();
    
    @Test
	public void registerRequestInvalidBrandTest() throws MobileServiceException{
    	
    	
    	Assertions.assertFalse(validator.isValidBrand("abc")); 
    	

	}
    
    @Test
	public void registerRequestInvalidContactNumberTest() throws MobileServiceException{
    	
    	Assertions.assertFalse(validator.isValidContactNumber(987654L));

		
	}
    @Test
	public void registerRequestInvalidIssuesTest() throws MobileServiceException{
		ArrayList<String> issue= new ArrayList<String>();
    	issue.add("broken screen");
    	ServiceRequest a =new ServiceRequest("Twoplusone", issue , 9876543210L, "John" , 1234567890123456L);
    	
		Exception e= Assertions.assertThrows(Exception.class, ()-> mobileService.registerRequest(a));
		Assertions.assertEquals("Service.INVALID_ISSUES",e.getMessage());
	}

}
